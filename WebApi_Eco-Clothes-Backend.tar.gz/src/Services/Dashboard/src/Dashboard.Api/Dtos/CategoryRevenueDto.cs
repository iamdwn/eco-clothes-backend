﻿namespace Dashboard.Api.Dtos
{
    public class CategoryRevenueDto
    {
        public string CategoryName { get; set; }
        public decimal TotalRevenue { get; set; }
    }
}
