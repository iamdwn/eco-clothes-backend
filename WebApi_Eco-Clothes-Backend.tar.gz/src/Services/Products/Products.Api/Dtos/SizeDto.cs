﻿namespace Products.Api.Dtos
{
    public class SizeDto
    {
        public string? SizeName { get; set; }
        public int SizeQuantity { get; set; }
    }
}
