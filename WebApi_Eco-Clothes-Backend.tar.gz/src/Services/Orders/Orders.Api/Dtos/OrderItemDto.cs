﻿//namespace EventBus.Events.Interfaces
//{
//    public class OrderItemDto
//    {
//        public Guid ProductId { get; set; }
//        public int Quantity { get; set; }
//        public decimal UnitPrice { get; set; }
//        public decimal TotalPrice { get; set; }
//        public string? SizeName { get; set; }
//    }
//}
