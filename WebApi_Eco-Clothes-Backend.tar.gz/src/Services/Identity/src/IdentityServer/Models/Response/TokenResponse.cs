﻿namespace IdentityServer.Models.Response
{
    public class TokenResponse
    {
        public string AccessToken { get; init; }
        public string RefreshToken { get; init; }
    }
}
