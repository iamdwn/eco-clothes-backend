﻿namespace IdentityServer.Models.DTOs
{
    public class AddRoleDTO
    {
        public string RoleName { get; set; }
    }
}
