﻿namespace IdentityServer.Models.DTOs
{
    public class ConfirmEmailDTO
    {
        public string UserId { get; set; }
        public string Code { get; set; }
    }
}
