﻿namespace IdentityServer.Models.DTOs
{
    public class GetTokenDTO
    {
        public string RefreshToken { get; set; }
    }
}
