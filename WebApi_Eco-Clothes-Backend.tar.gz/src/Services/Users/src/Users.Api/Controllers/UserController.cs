﻿namespace Users.Api.Controllers
{
    public class UserController
    {
    }
}
